package com.example.enchanted_event_hall

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
